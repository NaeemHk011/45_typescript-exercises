let a = 15;
let b = 5;
let c = 5;

console.log("Is a > b? I predict True.");
console.log(a > b);

console.log("Is a + b == 15? I predict True.");
console.log(a + b == 20);

console.log("Is b < c? I predict False.");
console.log(b < c);

console.log("Is a <= 20? I predict True.");
console.log(a <= 20);

console.log("Is a >= 11? I predict False.");
console.log(a >= 20);

console.log("Is b > c? I predict False.");
console.log(b > c);

console.log("Is a != 20? I predict false.");
console.log(a === 20);

console.log("Is c >= b? I predict false.");
console.log(c != b);

console.log("Is a % b == 0? I predict True.");
console.log(a % b == 0);

console.log("Is a - b != 5? I predict True.");
console.log(a - b != 5);

