var alien_color = "green";
if (alien_color == "green") {
    console.log("player just earned 5 points for shooting the alien:");
}
else {
    console.log("player  just earned 10 pint for shooting the alien");
}
//fail condition
var alien_color2 = "yellow";
if (alien_color2 == "red") {
    console.log("player just earned 5 points for shooting the alien:");
}
else {
    console.log("player  just earned 10 pint for shooting the alien");
}
