let alien_color:string = "green";
if(alien_color == "green"){
    console.log("player just earned 5 points for shooting the alien:");
}
else{
    console.log("player  just earned 10 pint for shooting the alien");
}

//fail condition
let alien_color2:string = "yellow";
if(alien_color2 == "red"){
    console.log("player just earned 5 points for shooting the alien:");
}
else{
    console.log("player  just earned 10 pint for shooting the alien");
}