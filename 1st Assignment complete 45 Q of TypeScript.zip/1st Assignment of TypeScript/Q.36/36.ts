function make_shirt(size:string, message:string){
    console.log(`The shirt is size ${size} and the message is ${message}: `);
}
make_shirt("large", "Welcome to typescript");