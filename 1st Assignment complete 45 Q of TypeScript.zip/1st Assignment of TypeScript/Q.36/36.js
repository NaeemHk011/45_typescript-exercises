function make_shirt(size, message) {
    console.log("The shirt is size ".concat(size, " and the message is ").concat(message, ": "));
}
make_shirt("large", "Welcome to typescript");
