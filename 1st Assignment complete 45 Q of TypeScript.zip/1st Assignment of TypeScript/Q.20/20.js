var country = [
    "pakistan",
    "Urdu",
    "5",
    "islamabad"
];
console.log(country);
