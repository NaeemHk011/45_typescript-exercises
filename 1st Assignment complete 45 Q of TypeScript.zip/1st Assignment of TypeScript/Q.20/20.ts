let country:string[] = [
    
        "pakistan",
        "Urdu",
        "5" ,
        "islamabad"
    
];
console.log(country);