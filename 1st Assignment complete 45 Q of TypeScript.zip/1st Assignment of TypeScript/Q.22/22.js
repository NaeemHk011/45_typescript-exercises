var arr = [2, 3, 23, 98];
console.log(arr[4]); //give an  error index 4 is out of bound;
console.log(arr[3]); // run in correct way
