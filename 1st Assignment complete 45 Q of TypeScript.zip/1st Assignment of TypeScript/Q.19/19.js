var guestName = ["Ahmed", "Asad", "Faheem"];
console.log("The ".concat(guestName.length, " guest are invited"));
