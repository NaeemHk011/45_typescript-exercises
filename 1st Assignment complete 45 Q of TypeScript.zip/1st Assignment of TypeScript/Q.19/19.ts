const guestName: string[] = ["Ahmed", "Asad", "Faheem"];
console.log(`The ${guestName.length} guest are invited`);