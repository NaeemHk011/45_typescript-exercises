var person = {
    name: 'Naeem',
    age: 20,
    occupation: 'Web devloper',
    hobbies: ['Reading', 'Eating']
};
console.log(person);
