function cities(city, country) {
    console.log(city, country);
}
cities("Karachi", "Pakistan");
cities("paris", "UK");
cities("sydeny", "Austrlia");
