function cities (city:string, country:string){
    console.log(city, country);
}
cities("Karachi", "Pakistan");
cities("paris", "UK");
cities("sydeny", "Austrlia");
