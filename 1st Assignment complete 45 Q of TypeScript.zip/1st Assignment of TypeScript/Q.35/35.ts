let animals:string[] = ["dog", "cat","lion"];
for(var i = 0; i <animals.length; i++){
    
    console.log(`A ${animals[i]} would make a great pet:`);
}
for(let j = 0; j <animals.length; j++){
    console.log(`${animals[j]} makes a great pet`)
        
}
