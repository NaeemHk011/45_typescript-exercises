var animals = ["dog", "cat", "lion"];
for (var i = 0; i < animals.length; i++) {
    console.log("A ".concat(animals[i], " would make a great pet:"));
}
for (var j = 0; j < animals.length; j++) {
    console.log("".concat(animals[j], " makes a great pet"));
}
