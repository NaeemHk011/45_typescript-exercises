var firstArray = ["Naeem", "Hussain", "Shehzad", "Faheem", "Ahmed"];
var secarray = ["bilal", "Shehzad", "hussain", "Faheem", "ahmed"];
for (var _i = 0, secarray_1 = secarray; _i < secarray_1.length; _i++) {
    var newUser = secarray_1[_i];
    var isUserTaken = false;
    for (var _a = 0, firstArray_1 = firstArray; _a < firstArray_1.length; _a++) {
        var currentUser = firstArray_1[_a];
        if (newUser.toLowerCase() === currentUser.toLowerCase()) {
            console.log("The username ".concat(newUser, " is already taken. Please choose a different username."));
            isUserTaken = true;
            break;
        }
    }
    if (!isUserTaken) {
        console.log("The username ".concat(newUser, " is available."));
    }
}
