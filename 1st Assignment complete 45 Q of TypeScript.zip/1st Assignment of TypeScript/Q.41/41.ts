function show_Magicians(magicians: string[]) {
    magicians.forEach(name => console.log(name));
}
const magiciansNames: string[] = ['Naeem', 'Shahmeer', 'Faheem'];
show_Magicians(magiciansNames);