function show_Magicians(magicians) {
    magicians.forEach(function (name) { return console.log(name); });
}
var magiciansNames = ['Naeem', 'Shahmeer', 'Faheem'];
show_Magicians(magiciansNames);
