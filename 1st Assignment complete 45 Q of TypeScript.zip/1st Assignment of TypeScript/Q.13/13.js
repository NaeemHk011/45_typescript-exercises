var transportation = ["Honda motorcycle", "boat", "Bicycle", "Areoplane"];
console.log("I would like to travel: " + transportation[2]);
