function orderSandwich(oreder) {
    console.log("you order a sandwich with ".concat(oreder, " on it. "));
}
orderSandwich(['pakistan', 'tommato', 'mayo']);
orderSandwich(['ham', 'cheese']);
orderSandwich(['indian', 'jelly']);
