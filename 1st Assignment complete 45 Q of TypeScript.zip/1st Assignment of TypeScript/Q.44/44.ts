function orderSandwich(oreder: string[]): void{
    console.log(`you order a sandwich with ${oreder} on it. `);
}
orderSandwich(['pakistan' , 'tommato', 'mayo']);
orderSandwich(['ham', 'cheese']);
orderSandwich(['indian', 'jelly']);