var names = ["Naeem", "Hussain", "Ahmed"];
console.log("Welcome in Developing Field " + names[0] + "\nWelcome in Developing Field  " + names[1]
    + " \nWelcome in Developing Field " + names[2]);
