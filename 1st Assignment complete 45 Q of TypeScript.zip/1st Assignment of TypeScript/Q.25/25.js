var alien_color = "green";
//passes if condition
if (alien_color == "green") {
    console.log("You have just earned five points:");
}
var alien_color1 = 'yellow';
//fail condition
if (alien_color1 == "green") {
    console.log("Your have just earned five points");
}
