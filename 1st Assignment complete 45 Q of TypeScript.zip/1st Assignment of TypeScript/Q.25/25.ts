let alien_color: string = "green";
//passes if condition
if(alien_color == "green"){
    console.log("You have just earned five points:");
}
let alien_color1:string = 'yellow';
//fail condition
if(alien_color1 == "green"){
    console.log("Your have just earned five points");
}