var pizzas = ["BBQ chicken", "stuffed", "tikka pizza"];
for (var i = 0; i < pizzas.length; i++) {
    console.log(pizzas[i]);
    console.log("i would rally like to " + pizzas[i]);
}
