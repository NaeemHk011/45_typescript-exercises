let alien_color:string = "yellow";
if(alien_color == "green"){
    console.log("player just have earned 5 points: ");
}
else if(alien_color == "yellow"){
    console.log("player just have earned 10 points:");
}
else{
    console.log("player have earned 15 points:");
}