console.log("Mirza Galib Once said, " + "\"Lest we forget: It is easy to be human, very hard to be humane\"");
