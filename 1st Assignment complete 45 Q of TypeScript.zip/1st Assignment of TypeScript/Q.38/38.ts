function showCity(city:string, country:string = "Pakistan"){
console.log(`The city is ${city} and the country name is ${country}`);
}
showCity("Karachi");
showCity("dubai", "UAE");
showCity("Sydeny", "australia");