function showCity(city, country) {
    if (country === void 0) { country = "Pakistan"; }
    console.log("The city is ".concat(city, " and the country name is ").concat(country));
}
showCity("Karachi");
showCity("dubai", "UAE");
showCity("Sydeny", "australia");
