// Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
var famous_person = "mirza galib";
var message = "Lest we forget: It is easy to be human, very hard to be humane";
console.log(famous_person + "said " + "\"".concat(message, "\""));
