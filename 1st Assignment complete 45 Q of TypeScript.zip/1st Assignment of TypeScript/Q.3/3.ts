let Name: string = "Naeem";
console.log(Name.toUpperCase());
console.log(Name.toLowerCase());
