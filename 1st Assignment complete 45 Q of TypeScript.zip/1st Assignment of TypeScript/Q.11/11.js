var names = ["Naeem", "Hussain", "Ahmed", "Shehzad", "Irfan"];
console.log(names);
