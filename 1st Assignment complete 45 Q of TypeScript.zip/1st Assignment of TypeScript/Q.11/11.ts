let names: string[] = ["Naeem", "Hussain", "Ahmed", "Shehzad", "Irfan"];
console.log(names);