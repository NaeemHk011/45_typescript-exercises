//My name store in variable. 
// this line is commented.
var username: string = "Naeem";
console.log(username);

/*thi is 
a Multi line Comment
commented line can't be executed in our 
 code*/