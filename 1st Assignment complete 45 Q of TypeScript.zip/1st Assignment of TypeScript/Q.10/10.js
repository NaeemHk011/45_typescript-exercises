//My name store in variable. 
// this line is commented.
var username = "Naeem";
console.log(username);
