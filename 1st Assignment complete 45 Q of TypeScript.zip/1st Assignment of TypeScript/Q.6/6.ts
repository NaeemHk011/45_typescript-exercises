let username: string = "Naeem Hussain";
console.log(`Name with white space: \t${username}\t  \n${username}`); 