var username = "Naeem Hussain";
console.log("Name with white space: \t".concat(username, "\t  \n").concat(username));
