let guessNumber:number = 5;
console.log('My fovourite number is:' + guessNumber);