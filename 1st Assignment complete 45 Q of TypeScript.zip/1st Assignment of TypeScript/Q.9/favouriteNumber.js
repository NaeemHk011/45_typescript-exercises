var guessNumber = 5;
console.log('My fovourite number is:' + guessNumber);