let gueslist: string[] = ["Ahmed", "Shehzad", "Irfan", "Faheem"];
for (var i = 0; i < gueslist.length; i++) {
    console.log(`Dear ${gueslist[i]}, 
    I would like to invitation for you to join me for dinner.
    Best Regards, 
    [Naeem Hussain]
    `);
}