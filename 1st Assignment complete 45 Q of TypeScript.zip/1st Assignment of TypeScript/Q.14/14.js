var gueslist = ["Ahmed", "Shehzad", "Irfan", "Faheem"];
for (var i = 0; i < gueslist.length; i++) {
    console.log("Dear ".concat(gueslist[i], ", \n    I would like to invitation for you to join me for dinner.\n    Best Regards, \n    [Naeem Hussain]\n    "));
}
