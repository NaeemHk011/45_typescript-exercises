var favorite_fruits = ["apple", "banana", "mango"];
if (favorite_fruits.includes("apple")) {
    console.log("you really like ");
}
if (favorite_fruits.includes("mango")) {
    console.log("your really like ");
}
if (favorite_fruits.includes("strewbary")) {
    console.log("your really like");
}
if (favorite_fruits.includes("grapes")) {
    console.log("you really like to ");
}
if (favorite_fruits.includes("banana")) {
    console.log("your really like ");
}
